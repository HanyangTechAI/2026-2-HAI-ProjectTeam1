# 시나리오 생성 비율 확인용 데이터

2026-11-17 생성. 수정된 `topic_balanced_v3`의 독립 시나리오 40개다.
조건은 budget 2048, H100, history 25000, noise 0.5, 제약 주제의 정책 3개,
시간 주제의 상태 변경 2회이며 seed 42·43에서 각각 20개씩 생성했다.

| 주제 | 개수 | 비율 | 파일 조회 | 이메일 |
|---|---:|---:|---:|---:|
| 제약 (`constraint`) | 10 | 25% | 5 | 5 |
| 시간·버전 (`temporal`) | 10 | 25% | 5 | 5 |
| 상태 (`state`) | 10 | 25% | 5 | 5 |
| Flexible 근거 (`flexible`) | 10 | 25% | 5 | 5 |
| 합계 | 40 | 100% | 20 | 20 |

## 실제 정보 구성 검사

- 제약 주제 10개: 실제 적용 정책 3개씩, 총 30개. 현재 요청에 파일 후보를 제공한다.
- 시간 주제 10개: 요청 시점에 맞는 STATE 1개와 다른 버전 2개씩 포함한다.
- 상태 주제 10개: 경쟁 버전 없이 정답에 필요한 현재 STATE와 예산 경쟁 자료를 포함한다.
- Flexible 주제 10개: 정답에 필요한 FACT와 예산 경쟁 자료를 포함한다.
- 고유 ID 40개, 주제별 역할 검사, 선언된 정답과 평가기의 일관성 검사 40개를 통과했다.

시간 주제도 STATE를 사용하므로 전체 `required_state_scenario_count`는 20이다.
이는 서로 겹치지 않는 주제별 개수 10개와 다른 집계다.

## 파일

- [`cell_12e5394f742d.json`](cell_12e5394f742d.json): 전체 입력 40개와 history, memory, 정답. Runner 입력 파일이다.
- [scenario_index.json](scenario_index.json): history를 제외한 40개 목록, 질의, 필수 정보 미리보기와 정답.
- [ratio_summary.json](ratio_summary.json): 비율 및 실제 정보 구성 집계.
- [manifest.json](manifest.json): 생성물 정보와 cell 경로.
- [config.json](config.json): 이 데이터의 생성 설정.

이 데이터는 비율 확인용 오프라인 입력이며 token count는 `provisional`이다.
LLM 실험은 수행하지 않았다. 주제 비율과 실제 ablation 성공률은 별도로 확인한다.
실제 모델 실험용 데이터는 Gemini counter로 새로 생성한다.

```powershell
python -m benchmark.generator --config benchmark/generated/topic_ratio_check_20261117/config.json --gemini-token-model gemini-3.1-flash-lite --archive --output benchmark/generated/topic_ratio_check_20261117_gemini.zip
```
